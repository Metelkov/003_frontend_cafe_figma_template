function visible__soupe() {

    document.getElementsByClassName('delicious-menu-selector-soupe').style.color ="red";
}


function visible__pizza () {
   
}

function visible__pasta () {
    document.getElementsByClassName('delicious-menu-selector-soupe').style.color ="red";

}

function visible__desert () {

}

function visible__wine () {

}

function visible__beer () {

}

function visible__drinks () {

}